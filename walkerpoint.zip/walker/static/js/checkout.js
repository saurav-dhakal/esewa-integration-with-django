// $(document).ready(function () {
//     $('.Pay_with_eSewa').click(function (e) { 
//         e.preventDefault();

//         var fname = $("[name='fname']").val();
//         var lname = $("[name='lname']").val();
//         var email = $("[name='email']").val();
//         var phone = $("[name='phone']").val();
//         var city = $("[name='city']").val();
//         var address = $("[name='address']").val();

//         var token = $('input[name=csrfmiddlewaretoken]').val();

       

//         if(fname=="" || lname=="" || email=="" || phone=="" || city=="" || address=="" )
//         {
//             alert('All fields are mandatory')
//             return false;
//         }
//         else{
//             $.ajax({
//                 type: "POST",
//                 url: "/esewapay",
//                 data:{

//                     csrfmiddlewaretoken:token
//                 },
//                 success: function (response) {
//                     data={
//                         'amount':response.amount,
//                         'tax_amount':response.tax_amount,
//                         'total_amount':response.total_amount,
//                         'transaction_uuid':response.transaction_uuid,
//                         'product_code':response.product_code,
//                         'product_service_charge':response.product_service_charge,
//                         'product_delivery_charge':response.product_delivery_charge,
//                         'success_url':response.success_url,
//                         'failure_url':response.failure_url,
//                         'signed_field_names':response.signed_field_names,
//                         'signature':response.signature,
//                         csrfmiddlewaretoken:token


//                     }
//                     $.ajax({                       
//                         type: "POST",
//                         url: "https://rc-epay.esewa.com.np/api/epay/main/v2/form",
//                         data: JSON.stringify(data),
//                         contentType: 'application/json',
//                         dataType: 'json',
//                         headers: { "X-CSRFToken": token },
//                         success: function (response) {
//                             console.log(response)
//                         }
//                     });
               
//                 }
                
//             });




//         }

        
//     });
// });


