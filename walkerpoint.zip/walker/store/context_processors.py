def cart(request):
    cart = request.session.get('cart', {})
    cart_count = len(cart.keys())  # Get the count of items in the cart
    return {'cart_count': cart_count}