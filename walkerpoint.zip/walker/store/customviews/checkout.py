from django.shortcuts import render, redirect,HttpResponseRedirect 
from django.contrib import messages
from django.http import HttpResponseServerError,JsonResponse
from django.urls import reverse
from store.models import Product, Cart,Order,OrderItem,Profile
from django.contrib.auth.decorators import login_required
import random
import hashlib
import xml.etree.ElementTree as ET
import requests 
import hashlib
from datetime import datetime

import base64
import json
from django.views import View
import uuid

from django.contrib.auth.models import User




@login_required(login_url='loginpage')
def index(request):
    rawcart = Cart.objects.filter(user=request.user)
    for item in rawcart:
        if item.qty > item.product.quantity:
            item.delete()

    cartitems = Cart.objects.filter(user=request.user)
    total_price=0
    for item in cartitems:
        price=item.product.selling_price * item.qty
        total_price = total_price + item.product.selling_price * item.qty

    userprofile=Profile.objects.filter(user=request.user).first()
    
    context={'cartitems':cartitems,'total_price':total_price,'userprofile':userprofile,'price':price}
    return render(request,'store/checkout.html',context)




@login_required(login_url='loginpage')
def placeorder(request):

    if request.method =="POST":
        currentuser=User.objects.filter(id=request.user.id).first()
        if not currentuser.first_name:
            currentuser.first_name=request.POST.get('fname')
            currentuser.last_name=request.POST.get('lname')
            currentuser.email=request.POST.get('email')

            currentuser.save()

        if not Profile.objects.filter(user=request.user):
            userprofile=Profile()
            userprofile.user=request.user
            userprofile.phone = request.POST.get('phone')
            userprofile.email = request.POST.get('email')
            userprofile.address = request.POST.get('address')
            userprofile.city = request.POST.get('city')
            userprofile.save()



        new_order = Order()
        new_order.user = request.user
        new_order.fname = request.POST.get('fname')
        new_order.lname = request.POST.get('lname')
        new_order.email = request.POST.get('email')
        new_order.phone = request.POST.get('phone')
        new_order.address = request.POST.get('address')
        new_order.city = request.POST.get('city')
        new_order.payment_mode = request.POST.get('payment_mode') 
        cart = Cart.objects.filter(user=request.user)
        cart_total_price=0
        for item in cart:
            cart_total_price=cart_total_price +item.product.selling_price * item.qty

        new_order.total_price = cart_total_price
        
        
        track = 'walker' + str(random.randint(1111111111,9999999999))

        while Order.objects.filter(tracking_number= track) is None:
            track = 'walker' + str(random.randint(1111111111,9999999999))

        new_order.tracking_number = track
        new_order.save()
        #for esewa payment mode
        if new_order.payment_mode == 'ESEWA':
            print("esewa")
            return redirect(reverse("esewarequest") + "?id=" + str(new_order.id))
        
        #for khalti payment
        if new_order.payment_mode == 'KHALTI':
            print("esewa")
            return redirect(reverse("initiatekhalti") + "?id=" + str(new_order.id))
        

        new_order_items = Cart.objects.filter(user=request.user)
        for item in new_order_items:
            OrderItem.objects.create(
                order=new_order,
                product=item.product,
                price=item.product.selling_price,
                quantity=item.qty
            )

            #decrease product quantity  in stock
            orderproduct = Product.objects.filter(id=item.product_id).first()
            orderproduct.quantity = orderproduct.quantity - item.qty
            orderproduct.save()

        #clear user's cart
        Cart.objects.filter(user=request.user).delete()
        messages.success(request,'Your order has been placed successfully')
    return redirect('/')


# @login_required(login_url='loginpage')      
# def payment_request(request):
#    payment_mode = request.POST.get('payment_mode')
#    a=payment_mode
#    print(a)
#    if payment_mode == 'ESEWA':
        
#         cart = Cart.objects.filter(user=request.user)
#         total_amount = sum(item.product.selling_price * item.qty for item in cart)

#         # Example usage
#         transaction_uuid = datetime.now().strftime("%y%m%d-%H%M%S")  # mimic the JavaScript date formatting
#         product_code ="EPAYTEST"  # replace with your actual value
#         secret_key = '8gBm/:&EnhH.1/q'

#         def generate_signature(total_amount, transaction_uuid, product_code, secret_key):
#             data_thash = f"total_amount={total_amount},transaction_uuid={transaction_uuid},product_code={product_code}"
#             hashed = hashlib.sha256((data_thash + secret_key).encode('utf-8')).digest()
#             signature = base64.b64encode(hashed).decode('utf-8')

        
#         # Generate the signature
#         signature = generate_signature(total_amount, transaction_uuid, product_code, secret_key)


#         url ="https://rc-epay.esewa.com.np/api/epay/main/v2/form"
#         data = {
#             "amount": total_amount,
#             "tax_amount": "0",
#             "total_amount": total_amount,
#             "transaction_uuid": transaction_uuid,
#             "product_code": product_code,
#             "product_service_charge": "0",
#             "product_delivery_charge": "0",
#             "success_url": "https://esewa.com.np",#esewa vrify
#             "failure_url": "https://google.com",
#             "signed_field_names": "total_amount,transaction_uuid,product_code",
#             "signature": signature,
#             }
#         resp = requests.post(url, data)
       

#    return redirect('/')


class EsewaRequestView(View):
    def get(self, request, *args, **kwargs):
        # Retrieve the order data and other necessary information
        id = str(request.GET.get("id"))
        print(id)
        order = Order.objects.get(id=id)  # Replace with your actual model and logic
        secret_key ='8gBm/:&EnhH.1/q'
        cart = Cart.objects.filter(user=request.user)
        total_amount = sum(item.product.selling_price * item.qty for item in cart)
        

        product_code ="EPAYTEST"  # replace with your actual value
        secret_key = '8gBm/:&EnhH.1/q'


        current_time = datetime.now()
        transaction_uuid = current_time.strftime("%y%m%d-%H%M%S")
        order.slug=transaction_uuid
        order.save()


        # def generate_signature(total_amount, transaction_uuid, product_code, secret_key):
        #     data_thash = f"total_amount={total_amount},transaction_uuid={transaction_uuid},product_code={product_code}"
        #     hashed = hashlib.sha256((data_thash + secret_key).encode('utf-8')).digest()
        #     signature = base64.b64encode(hashed).decode('utf-8')
        #     return signature

        # # Generate the signature
        # signature = generate_signature(total_amount, transaction_uuid, product_code, secret_key)

        # print("Generated Signature:", signature)
        success_url = f'http://127.0.0.1:8000/esewa-verify/'

        data = {
            "id":id,
            "amount": total_amount,
            "tax_amount": "0",
            "total_amount": total_amount,
            "product_code": product_code,
            "transaction_uuid":transaction_uuid,
            "product_service_charge": "0",
            "product_delivery_charge": "0",
            "success_url": success_url,
            "failure_url": "https://google.com",
            "signed_field_names": "total_amount,transaction_uuid,product_code",
            
        }
        # print(data['amount'])


        context = {
            "order": order,
            "data": data,
        }
        return render(request, "payment_integration/esewa.html", context)
    


# class EsewaVerifyView(View):
#     def get(self, request, *args, **kwargs):
        
#         id = request.GET.get("pid")
#         amt = request.GET.get("amt")
#         refId = request.GET.get("refId")
#         print(id)
#         print(amt)
#         print(refId)

#         url = "https://uat.esewa.com.np/epay/transrec"
#         data = {
#             'amt': amt,
#             'scd': 'EPAYTEST',
#             'rid': refId,
#             'pid': id,
#         }
#         try:
#             response = requests.post(url, data)
#             root = ET.fromstring(response.content)
#             status = root[0].text.strip()

      

#             if status == "COMPLETE":
#                 print('Payment successful')
#                 return redirect("viewcart")
#             else:
#                 print('rororororoorororoor')
#                 # return redirect("/esewa-request/?id=" + order_id)
        
#         except requests.exceptions.RequestException as e:
#             # Log or print the exception for debugging
#             print(f"Error in EsewaVerifyView: {str(e)}")
#             return HttpResponseServerError("Internal Server Error")


class EsewaVerifyView(View):
    
    def get(self, request, *args, **kwargs):
        
 
        if request.method == 'GET':
            try:
                # id =request.GET.get('id')
                data =request.GET.get('data')
                decoded_data = base64.b64decode(data).decode('utf-8')
                print(decoded_data)
                map_data = json.loads(decoded_data)
                print(map_data)
                # print(id)
                transaction_uuid = str(map_data['transaction_uuid'])
                new_order = Order.objects.filter(slug=transaction_uuid)
                print(new_order)

                # print(new_order)
                if map_data.get('status')== 'COMPLETE':
                    print(transaction_uuid)                   
                    new_order_items = Cart.objects.filter(user=request.user)
                    for item in new_order_items:
                        OrderItem.objects.create(
                            order=item.user.username,
                            product=item.product.name,
                            price=item.product.selling_price,
                            quantity=item.qty
                        )
                            

                        #decrease product quantity  in stock
                        orderproduct = Product.objects.filter(id=item.product_id).first()
                        orderproduct.quantity = orderproduct.quantity - item.qty
                        orderproduct.save()
                        if( Cart.objects.filter(user=request.user)):
                            Cart.objects.filter(user=request.user).delete()
                            messages.success(request,'Your order has been placed successfully')
                        
                    






                    # cart=Cart.objects.filter(user=request.user)
                    # for c in cart:
                    #     c.delete()
                    #     #clear user's cart
                    #     messages.success(request,'Your order has been placed successfully')
                    #     print("payment with esewa")
                    #     print('Payment successful')
                        return redirect("myorders")
                    else:
                        
                        print("payment not successfull")
                        messages.success(request,'Your payment is not successfull')
                        
                        return redirect('cart')

            except requests.exceptions.RequestException as e:
                print(e)
                return HttpResponseServerError("Internal Server Error")

# class initkhalti(View):
    
#     def get(self, request, *args, **kwargs):

#         id = request.GET.get("id")
#         order = Order.objects.get(id=id)  # Replace with your actual model and logic
#         uuids = str(uuid.uuid4())
        
#         cart = Cart.objects.filter(user=request.user)
#         total_amount = sum(item.product.selling_price * item.qty for item in cart)
#         url = "https://a.khalti.com/api/v2/epayment/initiate/"
#         return_url = "http://127.0.0.1:8000/verifykhalti"
#         website_url = "http://127.0.0.1:8000"
#         amount = total_amount
#         purchase_order_id = uuids


#         print("url",url)
#         print("return_url",return_url)
#         print("web_url",website_url)
#         print("amount",amount)
#         print("purchase_order_id",purchase_order_id)
#         payload = json.dumps({
#             "return_url": return_url,
#             "website_url": website_url,
#             "amount": amount,
#             "purchase_order_id": purchase_order_id,
#             "purchase_order_name": "test",
#             "customer_info": {
#             "name": "Bibek Dahal",
#             "email": "test@khalti.com",
#             "phone": "9800000001"
#             }
#         })
#         print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
#         # put your own live secet for admin
#         headers = {
#             'Authorization': 'key test_secret_key_d72d702eaa4f4627ae2085bac962d884',
#             'Content-Type': 'application/json',
#         }
        
#         response = requests.request("POST", url, headers=headers, data=payload)
#         print(json.loads(response.text))
#         print("yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy")
#         print(response.text)
#         new_res = json.loads(response.text)
#         # print(new_res['payment_url'])
#         print(type(new_res))
#         return redirect(new_res['payment_url'])
#         return redirect("home")


# class verifyKhalti(View):
    
#     def get(self, request, *args, **kwargs):

#         url = "https://a.khalti.com/api/v2/epayment/lookup/"
#         if request.method == 'GET':
#             headers = {
#                 'Authorization': 'key test_secret_key_dab65a7f59944e26a9e2cd1066a407bc',
#                 'Content-Type': 'application/json',
#             }
#             pidx = request.GET.get('pidx')
#             data = json.dumps({
#                 'pidx':pidx
#             })
#             res = requests.request('POST',url,headers=headers,data=data)
#             print(res)
#             print(res.text)

#             new_res = json.loads(res.text)
#             print(new_res)
            

#             if new_res['status'] == 'Completed':
#                 # user = request.user
#                 # user.has_verified_dairy = True
#                 # user.save()
#                 # perform your db interaction logic
#                 print("payment successful")
#                 pass
            
#             # else:
#             #     # give user a proper error message
#             #     raise BadRequest("sorry ")

#             return redirect('home')
        