from django.shortcuts import render, redirect
from django.contrib import messages
from store.models import Order,OrderItem,Cart
from django.contrib.auth.decorators import login_required



def index(request):
    # Cart.objects.filter(user=request.user).delete()
    # messages.success(request,'Your order has been placed successfully')
    orders=Order.objects.filter(user=request.user)
    context={'orders':orders}
    return render(request, 'store/order/myorder.html',context)


def orderview(request,t_no):
    order=Order.objects.filter(user=request.user).filter(tracking_number=t_no).first()
    orderitems = OrderItem.objects.filter(order=order)
    context={'order':order,'orderitems':orderitems}
    return render(request, 'store/order/orderview.html',context)