from django.urls import path
from . import views
from store.customviews import authview,cart,checkout,myorder

urlpatterns = [
    path('',views.home, name='home'),
    path('collections',views.collections, name='collections'),
    path('collections/<str:slug>',views.collectionsview, name='collectionsview'),
    path('collections/<str:cate_slug>/<str:prod_slug>',views.productview, name='productview'),
    path('product-list',views.productlistAjax, name='productlist'),
    path('searchproduct',views.searchproduct, name='searchproduct'),

    # for authentication
    path('register/',authview.register, name='register'),
    path('login/',authview.loginpage, name='loginpage'),
    path('logout/',authview.logoutpage, name='logout'), 

    path('add-to-cart',cart.addtocart, name='addtocart'),
    path('cart',cart.viewcart, name='viewcart'),
    path('update-cart',cart.updatecart, name='updatecart'),
    path('delete-cart-item',cart.deletecartitem, name='deletecartitem'),
    path('checkout/',checkout.index, name='checkout'),
    path('placeorder/',checkout.placeorder, name='placeorder'),

    # path("paymentmode/",checkout.paymentmode, name="paymentmode"),

    path("esewa-request/",checkout.EsewaRequestView.as_view(), name="esewarequest"),
    path("esewa-verify/", checkout.EsewaVerifyView.as_view(), name="esewaverify"),

    # path('initiatekhalti',checkout.initkhalti.as_view(),name="initiatekhalti"),
    # path('verifykhalti',checkout.verifyKhalti.as_view(),name="verifykhalti"),



    path('my-orders',myorder.index, name='myorders'),
    path('order-view/<str:t_no>',myorder.orderview, name='orderview'),
    path('order-view/',myorder.orderview, name='orderview'),
    path('termsandcondition/',views.termsandcondition, name='termsandcondition'),
    path('returnpolicy/',views.returnpolicy, name='returnpolicy'),
    path('privacypolicy/',views.privacypolicy, name='privacypolicy'),

    

    
]                                   