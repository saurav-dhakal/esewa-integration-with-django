from django.db import models
from django.contrib.auth.models import User
import datetime
import os
import uuid


# Create your models here.

def get_file_path(request,filename):
    original_filename = filename
    nowTime = datetime.datetime.now().strftime('%y%m%d%H:%M:%S')
    filename = "%s%s"% (nowTime, original_filename)
    return os.path.join('uploads/',filename)


class Category(models.Model):
    slug = models.CharField(max_length=150, null=False, blank=False)
    name = models.CharField(max_length=150, null=False, blank=False)
    image=models.ImageField(upload_to=get_file_path, null=True, blank=True )
    status = models.BooleanField(default=False, help_text="0=default, 1=Trending")
    meta_title = models.CharField(max_length=150, null=False, blank=False)
    meta_keywords = models.CharField(max_length=150, null=False, blank=False)
    meta_description = models.TextField(max_length=500, null=False, blank=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name
    

class Product(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    slug = models.CharField(max_length=150, null=False, blank=False)
    name = models.CharField(max_length=150, null=False, blank=False)
    volume = models.CharField(max_length=150,default="750ML")
    brand = models.CharField(max_length=150,default="...")
    alcohol = models.CharField(max_length=150,default="...")
    country = models.CharField(max_length=150,default="...")

    product_image=models.ImageField(upload_to=get_file_path, null=False, blank=False )

    quantity = models.IntegerField(null=False, blank=False,default="100")
    description = models.TextField(max_length=1800, null=False, blank=False)
    original_price = models.FloatField(null=False, blank=False)
    selling_price = models.FloatField(null=False, blank=False)
    status = models.BooleanField(default=False, help_text="0=default, 1=Offer")

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name
    

class Cart(models.Model):
    user=models.ForeignKey(User, on_delete=models.CASCADE)
    product=models.ForeignKey(Product, on_delete=models.CASCADE)
    qty = models.IntegerField(null=False,blank=False)
    created_at=models.DateTimeField(auto_now_add=True)

    def total_price(self):
        return self.product.selling_price * self.qty

    def __str__(self):
        return self.user.username
    



class Order(models.Model):
    id=models.AutoField(primary_key=True)
    slug = models.CharField(max_length=150,default="slug")
    user=models.ForeignKey(User, on_delete=models.CASCADE)
    fname=models.CharField(max_length=100,null=False)
    lname=models.CharField(max_length=100,null=False)
    email=models.CharField(max_length=100,null=False)
    phone=models.CharField(max_length=100,null=False)
    city=models.CharField(max_length=100,null=False)
    address=models.TextField(null=False)
    total_price=models.FloatField(null=False)
    tracking_number = models.CharField(max_length=150, null=True)
    payment_mode=models.CharField(max_length=200,null=False)
    payment_id=models.CharField(max_length=300,null=True)
    orderstatus={
        ('Pending','Pending'),
        ('Out For Shipping','Out For Shipping'),
        ('Completed','Completed')
    }
    status=models.CharField(max_length=200,choices=orderstatus, default='Pending')
    message=models.TextField(null=False)
    created_at =models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        # return self.user.username
        return f'{self.user.username}-{self.fname}'
    
    

class OrderItem(models.Model):
    # order=models.ForeignKey(Order, on_delete=models.CASCADE)
    # product=models.ForeignKey(Product, on_delete=models.CASCADE)
    order=models.CharField(max_length=100,null=False)
    product=models.CharField(max_length=100,null=False)
    
    price=models.FloatField(null=False)
    quantity=models.IntegerField(null=False)

    def __str__(self):
        return f'{self.order} -{self.product}-{self.price}'


class Profile(models.Model):
    user=models.ForeignKey(User, on_delete=models.CASCADE,default="")
    fname=models.CharField(max_length=100,null=False)
    lname=models.CharField(max_length=100,null=False)  
    email=models.CharField(max_length=100,null=False)
    phone=models.CharField(max_length=100,null=False)
    city=models.CharField(max_length=100,null=False)
    address=models.TextField(null=False)
    created_at =models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.user.username
