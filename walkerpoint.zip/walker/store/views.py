from django.shortcuts import render, redirect,get_object_or_404
from django.contrib import messages
from.models import *
from django.http.response import JsonResponse

# Create your views here.

def home(request):
    s=dict(request.session)
    print(s)
    print(s)
    print(s)
    print(s)
    print(s)
    print(s)
    print(s)
    allproductforoffer = Product.objects.all()
    offer_item=Product.objects.filter(status=1)
    category=Category.objects.all()
    allProds = []
    catprods = Product.objects.values('category', 'id')
    cats = {item['category'] for item in catprods}
    
    for cat in cats:
        prod = Product.objects.filter(category=cat)
        allProds.append(prod)
    return render(request,"store/index.html",{'allProds':allProds,'category':category,'offer_item':offer_item,'allproductforoffer':allproductforoffer})

def collections(request):
    category= Category.objects.all()
    context= {'category':category}
    return render(request,"store/collections.html",context)

def productlistAjax(request):
    products = Product.objects.filter(status=0).values_list('name',flat=True)
    productlist = list(products)
    return JsonResponse(productlist,safe=False)

def searchproduct(request):
    if request.method =='POST':
        searchedtern=request.POST.get('productsearch')
        if searchedtern =="":
            return redirect(request.META.get('HTTP_REFERER'))
        
        else:
            product=Product.objects.filter(name__contains=searchedtern).first()

            if product:
                return redirect('collections/'+product.category.slug)
            else:
                messages.info(request,"No product matched your search")
                return redirect(request.META.get('HTTP_REFERER'))
            
    return redirect(request.META.get('HTTP_REFERER'))



def collectionsview(request, slug):
    if(Category.objects.filter(slug=slug, status=0)):
        category=Category.objects.all()
        allProds = []
        catprods = Product.objects.values('category', 'id')
        cats = {item['category'] for item in catprods}
        
        for cat in cats:
            prod = Product.objects.filter(category=cat)
            allProds.append(prod)
        products=Product.objects.filter(category__slug=slug)
        category = Category.objects.filter(slug=slug).first()
        context = {'products':products,'category':category,'allProds':allProds}
        return render(request,"store/products/index.html",context)
    
    else:
        messages.warning(request,"No such category found")
        return redirect('collections')
             

def productview(request,cate_slug,prod_slug):
    if(Category.objects.filter(slug=cate_slug)):
        if(Product.objects.filter(slug=prod_slug)):
            offer_item=Product.objects.filter(status=1)

            category=Category.objects.all()
            allProds = []
            catprods = Product.objects.values('category', 'id')
            cats = {item['category'] for item in catprods}
            
            for cat in cats:
                prod = Product.objects.filter(category=cat)
                allProds.append(prod)

            products=Product.objects.filter(slug=prod_slug).first
            context = {'products':products,'allProds':allProds,'offer_item':offer_item}
        else:
             messages.warning(request,"No such product found")

    else:
        messages.warning(request,"No such category found")
        return redirect('collections')
    return render(request,"store/products/view.html",context)
             


def termsandcondition(request):
    return render(request,"store/termsandcondition.html")


def privacypolicy(request):
    return render(request,"store/privacypolicy.html")

def returnpolicy(request):
    return render(request,"store/returnpolicy.html")